echo "1.       Start Pre-requists..........."
cd ~

echo "2.       clone WebLogic Kubernetes Operator......"
git clone https://github.com/oracle/weblogic-kubernetes-operator

echo "3.        Pull Oracle WebLogic Kubernetes operator....."
docker pull oracle/weblogic-kubernetes-operator:2.60

echo "3.        pull traefik...."
docker pull traefik:1.7.12

echo "4.        pull container-registry.oracle.com/middleware/weblogic:12.2.1.4...."
docker pull container-registry.oracle.com/middleware/weblogic:12.2.1.4

echo "5.        Kubectl apply Service account...."
cat <<EOF | kubectl apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: helm-user-cluster-admin-role
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: default
  namespace: kube-system
EOF

echo "6.        running helm repo add stable https://kubernetes-charts.storage.googleapis.com/ command..... "  
helm repo add stable https://kubernetes-charts.storage.googleapis.com/

echo "Running kubectl create namespace traefik .... "
kubectl create namespace traefik

echo "7.        go to path  weblogic-kubernetes-operator..."
cd weblogic-kubernetes-operator/

echo "8.        helm install stable/traefix..."
helm install stable/traefik \
--name traefik-operator \
--namespace traefik \
--values kubernetes/samples/charts/traefik/values.yaml \
--set "kubernetes.namespaces={traefik}" \
--wait

echo "9.         kubectl create namespace sample-weblogic-operators-ns .... "
kubectl create namespace sample-weblogic-operators-ns
kubectl create serviceaccount -n sample-weblogic-operators-ns sample-weblogic-operators-sa

echo "10.        helm install kubernetes/charts/weblogic-operator ..."
helm install kubernetes/charts/weblogic-operator \
--name sample-weblogic-operators \
--namespace sample-weblogic-operators-ns \
--set image=oracle/weblogic-kubernetes-operator:2.6.0 \
--set serviceAccount=sample-weblogic-operators-sa \
--set "domainNamespaces={}" \
--wait

#kubectl logs -n sample-weblogic-operators-ns -c weblogic-operator deployments/weblogic-operator

echo "11.        kubectl create namespace $1."
kubectl create namespace $1

echo "12.        helm updgrade..."
helm upgrade sample-weblogic-operators kubernetes/charts/weblogic-operator \
--namespace sample-weblogic-operators-ns \
--reuse-values \
--set "domainNamespaces={$1}" \
--wait

echo "13.         helm updgrade..."
helm upgrade traefik-operator stable/traefik \
--namespace traefik \
--reuse-values \
--set "kubernetes.namespaces={traefik,$1}" \
--wait

#echo "14.         go to path weblogic-kubernetes-operator/kubernetes/samples/scripts/create-weblogic-domain-credentials ..."
#cd /home/opc/weblogic-kubernetes-operator/kubernetes/samples/scripts/create-weblogic-domain-credentials/

#echo "15.         Running create-weblogic-credentials.sh -u weblogic -p welcome1 -n sample-domains1-ns -d sample-domains1..."
#./create-weblogic-credentials.sh -u weblogic -p welcome1 -n $1 -d sample-domains1

helm upgrade sample-weblogic-operators kubernetes/charts/weblogic-operator \
--reuse-values \
--set "elkIntegrationEnabled=true"

kubectl apply -f kubernetes/samples/scripts/elasticsearch-and-kibana/elasticsearch_and_kibana.yaml -n $1
