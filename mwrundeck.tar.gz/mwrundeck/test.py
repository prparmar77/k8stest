cd /tmp/$0/weblogic-domains1/$1
sed -i 's/"weblogic.domainUID: $1"/"weblogic.domainUID: $1\n    ruser: $2"/g' domain.yaml'
cat domain.yaml
