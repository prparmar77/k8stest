##############################################
# Original Author : Nagesh Kumar 
# Creation Date : 24-Mar-2020 
# Filename : createwls12c.py.
# Modified By : 
##############################################
import subprocess
import os
import sys
import jinja2
import time
from jinja2 import Environment, PackageLoader
instance_ip = "132.145.163.221"
instance_nodename = "masterk8s" 
instance_identityfile = "/home/rundeck/mwrundeck/id_rsa"
taglabel			= sys.argv[1]
ruser                           = sys.argv[2]
namespace			= sys.argv[3]

	
print(("Connecting Node %s")%(instance_nodename))

print("Executing the Automation Process to Provision WebLogic Environment Managed by Kubernetes")



try:
    command = "ssh -x opc@%s -i %s 'sudo bash -c \"mkdir /mnt/mwdbfs/oracle/%s;chown oracle:oinstall /mnt/mwdbfs/oracle/%s \" \' " %(instance_ip,instance_identityfile,taglabel,taglabel )
    output = subprocess.check_output(['bash','-c', command])

    command = "ssh -x opc@%s -i %s 'bash -c \"mkdir /home/opc/wlsk8s/%s \" \' " %(instance_ip,instance_identityfile,taglabel )
    output = subprocess.check_output(['bash','-c', command])

except subprocess.CalledProcessError as e:

    print("Attempt to create WLS setup with same taglabel,contact your administrator or retry with different taglabel")
    exit()


try:
    command = "scp -i %s  /home/rundeck/mwrundeck/prewls.sh opc@%s:/home/opc/wlsk8s/%s/prewls.sh" %(instance_identityfile,instance_ip,taglabel)
    output = subprocess.check_output(['bash','-c', command])

except subprocess.CalledProcessError as e:
    print("Copy failed to create Pre-req file from Rundeck to MAster Node")
    exit()



try:
    command = "ssh -x opc@%s -i %s 'sudo bash -c \"/home/opc/wlsk8s/%s/prewls.sh %s \" \' " %(instance_ip,instance_identityfile,taglabel,namespace)
    output = subprocess.check_output(['bash','-c', command])
except subprocess.CalledProcessError as e:
    print("Setup of Operator or dependencies failed")
    exit()
