


cd /home/opc/wlsk8s/admin/weblogic-domains/testwls/

cp domain.yaml domain.yaml.backup 

cat domain.yaml.backup | sed '/env:/r/home/opc/wlsk8s/classpath.txt' > tmp.txt

mv tmp.txt domain.yaml


