echo $1
echo $2
sed -i "s/weblogic.domainUID: $2/weblogic.domainUID: $2\n    ruser: $1/g" /home/opc/wlsk8s/$1/weblogic-domains/$2/domain.yaml
sed -i "s/affinity:/labels:\n        ruser: $1\n    affinity:/g" /home/opc/wlsk8s/$1/weblogic-domains/$2/domain.yaml
sed -i "s/env:/labels:\n      ruser: $1\n    env:/g" /home/opc/wlsk8s/$1/weblogic-domains/$2/domain.yaml
