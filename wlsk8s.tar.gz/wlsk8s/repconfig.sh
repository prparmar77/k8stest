echo "taglabel" $1
echo "Domain UID" $2
echo "Domain Namespace" $3
echo "DB host" $4
echo "DB Port" $5
echo "DB Service Name" $6
echo "DB User" $7
echo "DB Password *******"
echo "DS Name" $9
echo "SUbmitting User" "${10}"


cp /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml.template /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

sed -i "s/domainUIDns/$3/g" /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

sed -i "s/domainUIDnm/$2/g" /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

kubectl -n $3 delete cm $2-overrides-cm

kubectl -n $3 create cm $2-overrides-cm \
--from-file /home/opc/wlsk8s/jdbc_ds/version.txt \
--from-file /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

kubectl -n $3 label cm/$2-overrides-cm \
weblogic.domainUID=$2


cp /home/opc/wlsk8s/jdbc_ds/secret.sh.template /home/opc/wlsk8s/jdbc_ds/secret.sh

sed -i "s/domainns/$3/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/domainnm/$2/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsHost/$4/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsPort/$5/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsServiceName/$6/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsPassword/$8/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsUsrName/$7/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
sed -i "s/dsName/$9/g" /home/opc/wlsk8s/jdbc_ds/secret.sh
chmod +x /home/opc/wlsk8s/jdbc_ds/secret.sh

/home/opc/wlsk8s/jdbc_ds/secret.sh

cp /home/opc/wlsk8s/${10}/weblogic-domains/$2/domain.yaml /home/opc/wlsk8s/${10}/weblogic-domains/$2/domain.yaml.ori

sed -i "s#includeServerOutInPodLog: true#includeServerOutInPodLog: true\n  configurations: {}\n  configOverrides: $2-overrides-cm\n  configOverrideSecrets: [$2-oracle-secret]#g" /home/opc/wlsk8s/${10}/weblogic-domains/$2/domain.yaml

kubectl -n $3 apply -f /home/opc/wlsk8s/${10}/weblogic-domains/$2/domain.yaml --force


kubectl get domain $2 -n $3 -o yaml > domain-restart-$2.yaml && sed -i "s/IF_NEEDED/NEVER/g" domain-restart-$2.yaml && kubectl replace -f domain-restart-$2.yaml --force

sleep 100s

# kubectl wait --timeout=200s --for=delete pod -l weblogic.domainUID=$2 -n $3

kubectl get domain $2 -n $3 -o yaml > domain-restart-$2.yaml && sed -i "s/NEVER/IF_NEEDED/g" domain-restart-$2.yaml && kubectl replace -f domain-restart-$2.yaml --force

sleep 30s

kubectl wait --timeout=200s --for=condition=ready pod -l weblogic.domainUID=$2 -n $3

