echo $1
echo $2
sed -i "s#includeServerOutInPodLog: true#includeServerOutInPodLog: true\n  configuration:\n    overridesConfigMap: $2-overrides-cm\n    secrets: [$2-mysql-secret]#g" /home/opc/wlsk8s/$1/weblogic-domains/$2/domain.yaml
