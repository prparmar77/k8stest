kubectl -n sample-domains1-ns delete secret  testwls-oracle-secret

kubectl -n sample-domains1-ns  create secret generic testwls-oracle-secret \
--from-literal=username=system \
--from-literal=password=Oracle123 \
--from-literal=url=jdbc:oracle:thin:@//132.145.91.29:32200/BCAP

kubectl -n sample-domains1-ns label secret testwls-oracle-secret  \
weblogic.domainUID=testwls
