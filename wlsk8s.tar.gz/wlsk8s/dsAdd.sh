echo $1
echo $2
export DOMAIN_HOME_IMAGE=/home/opc/weblogic-kubernetes-operator/kubernetes/samples/scripts/create-weblogic-domain/domain-home-in-image

cd $DOMAIN_HOME_IMAGE/docker-images/OracleWebLogic/samples/12213-domain-home-in-image/container-scripts

cp create-wls-domain.py create-wls-domain.py.backup

cat create-wls-domain.py.backup | sed '/assign(/r/home/opc/wlsk8s/jdbc_ds/jdbc-snippet.txt' > tmp$2.txt


mv tmp$2.txt create-wls-domain.py

sed -i "s/import os/import os\nfrom weblogic.management.configuration import TargetMBean/g" create-wls-domain.py

sed -i "s/domainUIDns/$1/g" /home/opc/wlsk8s/jdbc_ds/mysql.yaml

sed -i "s/domainUIDnm/$2/g" /home/opc/wlsk8s/jdbc_ds/mysql.yaml

kubectl apply -f /home/opc/wlsk8s/jdbc_ds/mysql.yaml

cp /home/opc/wlsk8s/jdbc_ds/jdbc-mysqlDS.xml.template /home/opc/wlsk8s/jdbc_ds/jdbc-mysqlDS.xml

sed -i "s/domainUIDns/$1/g" /home/opc/wlsk8s/jdbc_ds/jdbc-mysqlDS.xml

sed -i "s/domainUIDnm/$2/g" /home/opc/wlsk8s/jdbc_ds/jdbc-mysqlDS.xml

cp /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml.template /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

sed -i 's/domainUIDns/$1/g' /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

sed -i 's/domainUIDnm/$2/g' /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

cat /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

kubectl -n $1 delete cm $2-overrides-cm

kubectl -n $1 create cm $2-overrides-cm \
--from-file /home/opc/wlsk8s/jdbc_ds/version.txt \
--from-file /home/opc/wlsk8s/jdbc_ds/jdbc-mysqlDS.xml \
--from-file /home/opc/wlsk8s/jdbc_ds/jdbc-oracleDS.xml

kubectl -n $1 label cm/$2-overrides-cm \
weblogic.domainUID=$2

