import json
import os

a_file = open("domaincheck.json", "r")
json_object = json.load(a_file)
# a_file.close()

env_file = open("env.json","rw")
json_object_env = json.loads(env_file)
env_file.close()

json_object["spec"]["serverPod"]["env"] = json.dump(json_object_env,domaincheck.json)
a_file = open("domaincheck-clp.json", "w")
json.dump(json_object, a_file)
jq . domaincheck-clp.json
a_file.close()
