echo $1
echo $2
echo $3
export CLASSPATH=${3}
echo ${CLASSPATH}
case `grep -Fx "CLASSPATH" "" >/dev/null; echo $?` in
  0)
    # code if found
   kubectl get domains $1 -n $2 -o json | jq '.spec.serverPod.env[2]'

   echo "kubectl get domains $1 -n $2 -o json | jq '.spec.serverPod.env[2].value = \"CLASSPATH\"' | kubectl replace -f -" > tmp-$1-$2-classpath.sh

   sed -i "s#CLASSPATH#${3}#g" tmp-$1-$2-classpath.sh

   chmod +x tmp-$1-$2-classpath.sh

   ./tmp-$1-$2-classpath.sh

   sleep 30s

   kubectl wait --timeout=200s --for=condition=ready pod -l weblogic.domainUID=$1 -n $2

    ;;
  1)
    # code if not found
    
    ;;
  *)
    # code if an error occurred
    ;;
esac



