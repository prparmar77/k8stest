echo $1
echo $2
echo $3
export USER_MEM_ARGS=${3}
echo ${USER_MEM_ARGS}

echo "kubectl get domains $1 -n $2 -o json | jq '.spec.serverPod.env[1].value = \"USER_MEM_ARGS\"' | kubectl replace -f -" > tmp-$1-$2.sh

sed -i "s#USER_MEM_ARGS#${3}#g" tmp-$1-$2.sh

chmod +x tmp-$1-$2.sh

./tmp-$1-$2.sh



