
echo "Deployment AppName" $1
echo "Deployment filename" $2
echo "Deployment type" $3
echo "Domain UID" $4
echo "Domain User" $5

export DOMAIN_HOME_IMAGE=/home/opc/weblogic-kubernetes-operator/kubernetes/samples/scripts/create-weblogic-domain/domain-home-in-image

export APP_FILE_LOCATION=$DOMAIN_HOME_IMAGE/docker-images/OracleWebLogic/samples/12213-domain-home-in-image/container-scripts

cd $DOMAIN_HOME_IMAGE/docker-images/OracleWebLogic/samples/12213-domain-home-in-image/container-scripts

cp /home/opc/wlsk8s/$5/weblogic-domains/$4/$2.$3 .

cp /home/opc/wlsk8s/wls-exporter.war .

cp create-wls-domain.py create-wls-domain.py.backup

cp /home/opc/wlsk8s/appdeploy/app-deploy.txt.template /home/opc/wlsk8s/appdeploy/app-deploy.txt

sed -i "s/appName/$1/g" /home/opc/wlsk8s/appdeploy/app-deploy.txt

sed -i "s/filename/$2/g" /home/opc/wlsk8s/appdeploy/app-deploy.txt

sed -i "s/deptype/$3/g" /home/opc/wlsk8s/appdeploy/app-deploy.txt 

cat create-wls-domain.py.backup | sed '/deploy/r/home/opc/wlsk8s/appdeploy/app-deploy.txt' > tmp$4-app.txt

mv tmp$4-app.txt create-wls-domain.py

sed -i "s/import os/import os\nfrom weblogic.management.configuration import TargetMBean/g" create-wls-domain.py
