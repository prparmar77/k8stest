echo $1
echo $2
export DOMAIN_HOME_IMAGE=/home/opc/weblogic-kubernetes-operator/kubernetes/samples/scripts/create-weblogic-domain/domain-home-in-image

export APP_FILE_LOCATION=$DOMAIN_HOME_IMAGE/docker-images/OracleWebLogic/samples/12213-domain-home-in-image/container-scripts

cd $DOMAIN_HOME_IMAGE/docker-images/OracleWebLogic/samples/12213-domain-home-in-image/container-scripts

cp /home/opc/wlsk8s/testds.war .
