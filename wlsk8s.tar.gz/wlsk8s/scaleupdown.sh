echo $1
echo $2
echo $3
kubectl get domain $1 -n $2 -o yaml > domain-scale-$1.yaml && sed -i "s/replicas: .*$/replicas: $3/g" domain-scale-$1.yaml && kubectl replace -f domain-scale-$1.yaml

#while [[ $(kubectl get pods -l weblogic.domainUID=$1 -n $2 -o 'jsonpath={..status.conditions[?(@.Type=="Ready")].status}') != "True" ]]; do echo "waiting for pod" && sleep 1; done; 

sleep 10s

kubectl wait --timeout=200s --for=condition=ready pod -l weblogic.domainUID=$1 -n $2
