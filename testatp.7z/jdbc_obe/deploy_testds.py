connect('weblogic','Welcome1','host01.example.com:8001')
name = 'TestDS'
location = 'testds.war'

deploy(name, location, targets='dizzy1')