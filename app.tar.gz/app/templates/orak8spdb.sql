prompt Setting file dest
alter system set db_create_file_dest = "/u02/app/oracle/oradata/ORCL";
prompt Creating Pluggable Database
CREATE PLUGGABLE DATABASE {{ dbpdb  }} ADMIN USER pdb_adm IDENTIFIED BY {{ password  }};
prompt Opening Pluggable Database
ALTER PLUGGABLE DATABASE {{ dbpdb  }} OPEN;

ALTER PLUGGABLE DATABASE {{ dbpdb  }} SAVE STATE;
