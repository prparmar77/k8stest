alter system set db_create_file_dest = "/opt/oracle/oradata";

CREATE PLUGGABLE DATABASE {{ targetpdb  }}  from {{ dbpdb  }};

ALTER PLUGGABLE DATABASE {{ targetpdb  }} OPEN;

ALTER PLUGGABLE DATABASE {{ targetpdb  }} SAVE STATE;
