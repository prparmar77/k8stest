alter pluggable database {{ dbpdb }} CLOSE;

alter session set container = {{ dbpdb }} ;

alter pluggable database {{ dbpdb }}  refresh;

alter pluggable database {{ dbpdb }} open read only;

