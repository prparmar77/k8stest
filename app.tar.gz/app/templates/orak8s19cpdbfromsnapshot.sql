alter system set db_create_file_dest = "/opt/oracle/oradata";

CREATE PLUGGABLE DATABASE {{ dbpdb  }} from {{ sourcepdb }} using SNAPSHOT {{ snapshotname }};

ALTER PLUGGABLE DATABASE {{ dbpdb  }} OPEN;

ALTER PLUGGABLE DATABASE {{ dbpdb  }} SAVE STATE;
