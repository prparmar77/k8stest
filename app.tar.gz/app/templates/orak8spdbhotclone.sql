alter system set db_create_file_dest = "/u02/app/oracle/oradata/ORCL";
prompt System file dest set 
CREATE PLUGGABLE DATABASE {{ targetpdb }} from {{ dbpdb  }};
prompt Hot clone of Pluggable database created 
ALTER PLUGGABLE DATABASE {{ targetpdb  }} OPEN;
prompt Opening Cloned database in Read Write Mode
ALTER PLUGGABLE DATABASE {{ targetpdb }} SAVE STATE;
