create or replace database link {{ dbname }}cdb_link connect to system identified by {{ dbpassword  }}  using '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = {{ dbname }}CDB )))';

create pluggable database {{ dbpdb }} from {{ sourcepdb }}@{{ dbname }}cdb_link refresh mode manual;

alter pluggable database {{ dbpdb }} open read only ;

grant sysoper to system container=all;
