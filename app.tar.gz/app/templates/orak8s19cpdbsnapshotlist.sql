set linesize 150 
COL PDBNAME FORMAT a18
COL SNAPNAME FORMAT a32
select pdb_name PDBNAME,snapshot_name SNAPNAME ,SNAPSHOT_SCN SNAPSCN ,SNAPSHOT_TIME SNAPTIME from dba_pdbs a,dba_pdb_snapshots s where a.con_uid=s.con_uid and a.pdb_name = upper('{{ dbpdb  }}');

