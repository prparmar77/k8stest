alter system set db_create_file_dest = "/opt/oracle/oradata";

CREATE PLUGGABLE DATABASE {{ dbpdb  }} ADMIN USER pdb_adm IDENTIFIED BY {{ password  }};

ALTER PLUGGABLE DATABASE {{ dbpdb  }} OPEN;

ALTER PLUGGABLE DATABASE {{ dbpdb  }} SAVE STATE;
