alter session set container = {{ dbpdb }};
alter pluggable database snapshot {{ targetsnap  }};
REM "Snapshot created"
exit


