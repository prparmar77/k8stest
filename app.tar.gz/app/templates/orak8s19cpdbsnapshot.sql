alter session set container = {{ dbpdb }};
alter pluggable database snapshot {{ targetsnap  }};
REM "Snapshot created"
prompt Snapshot Created
exit


