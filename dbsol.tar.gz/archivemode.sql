alter system set CLONEDB=true scope = spfile;

shutdown immediate;

startup mount; 

alter database archivelog; 

alter database open;

exit
