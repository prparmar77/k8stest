
alter system set "_exadata_feature_on"=true scope=spfile;

shutdown immediate;

startup mount; 

alter database archivelog; 

alter database open;

exit
