import commands
import sys
n=1
timeelapsed=0
seperator="\n"
ruser=sys.argv[1]
while n==1:
 cmd =  'kubectl get pod -l ruser=%s' %(ruser)
 result = commands.getstatusoutput(cmd)
 if result[1] == str("No resources found."):
   print "No Database found under user"
   n=0
 else:
   cmd = "kubectl get services -l ruser=%s -o=jsonpath=" % (ruser) 
   cmd = cmd + ''''{range .items[*]}{.metadata.name}-{.metadata.labels.version}'''
   cmd = cmd +  "{\"\\n\"}{end}'"
   # print cmd
   result = commands.getstatusoutput(cmd)
    # print result[1]
   for lines in result[1].splitlines():
    dbtag = lines.split('-',4)[0]
    dbname = lines.split('-',4)[1]
    dbversion = lines.split('-',4)[3]
    
    print  'DB Tag Label :  %s DB Name : %s  DB Version : %s' %(dbtag,dbname,dbversion) 
    if dbversion == "12.2.0.1":
     cmd='cat /home/opc/orak8s/checkpdb.sql | kubectl exec -i  %s-0  -- env ORACLE_HOME=/u01/app/oracle/product/12.2.0/dbhome_1 ORACLE_SID=%scdb /u01/app/oracle/product/12.2.0/dbhome_1/bin/sqlplus -S / as sysdba' %(dbtag,dbname) 
     # print cmd
     result = commands.getstatusoutput(cmd) 
     print result[1]
    else:
     dbname = dbname.upper()
     # print dbname
     cmd='cat /home/opc/orak8s/checkpdb.sql | kubectl exec -i  %s-0  -- env ORACLE_HOME=/opt/oracle/product/19c/dbhome_1 ORACLE_SID=%sCDB /opt/oracle/product/19c/dbhome_1/bin/sqlplus -S / as sysdba' %(dbtag,dbname)
     # print cmd
     result = commands.getstatusoutput(cmd)
     print result[1]
     
   sys.exit()
   



