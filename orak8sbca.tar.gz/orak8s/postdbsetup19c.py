import time
import commands
import sys
n=1
timeelapsed=0
taglabel=sys.argv[1]
dbbackup = sys.argv[2]
dbname = sys.argv[3]
dbpassword = sys.argv[4]
while n==1:
 cmd = "kubectl logs %s-0 | grep 'DATABASE IS READY TO USE!'" %(taglabel) 
 result = commands.getstatusoutput(cmd)
 if result[1] == str("DATABASE IS READY TO USE!"):
   print "Database is ready for use"
   print "Executing Post Creation Setup" 
   if dbbackup == 'Yes':
     dbname = dbname.upper()
     print dbname
     cmd='cat /home/opc/orak8s/archivemode19c.sql | kubectl exec -i  %s-0  -- env ORACLE_HOME=/opt/oracle/product/19c/dbhome_1 ORACLE_SID=%sCDB /opt/oracle/product/19c/dbhome_1/bin/sqlplus -S sys/%s as sysdba' %(taglabel,dbname,dbpassword)
     print "Database in archive Mode,setting up required parameters"
     # print cmd
     result = commands.getstatusoutput(cmd)
     print result[1]
     print "Done doing changes"
   n=0
 else:
   print "Database is coming up ,hang tight"
   time.sleep(20)
   timeelapsed=timeelapsed + 20
   if timeelapsed == 1200:
    print "Looks like DB is taking little longer to start,please check after sometime by connecting from client"
    sys.exit()
   



