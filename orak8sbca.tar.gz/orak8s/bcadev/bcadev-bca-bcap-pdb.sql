alter system set db_create_file_dest = "/opt/oracle/oradata";

CREATE PLUGGABLE DATABASE bcap ADMIN USER pdb_adm IDENTIFIED BY Oracle123;

ALTER PLUGGABLE DATABASE bcap OPEN;

ALTER PLUGGABLE DATABASE bcap SAVE STATE;