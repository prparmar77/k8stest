IMAGE_NAME=$1
DOCKERFILE='Dockerfile'
BUILD_START=$(date '+%s')
docker build --force-rm=true --no-cache=true -t $IMAGE_NAME -f $DOCKERFILE . || {
  echo ""
  echo "ERROR: Oracle Boostrap Database Docker Image was NOT successfully created."
  echo "ERROR: Check the output and correct any reported problems with the docker build operation."
  exit 1
}
