#!/bin/bash
# LICENSE UPL 1.0
#
# Copyright (c) 1982-2018 Oracle and/or its affiliates. All rights reserved.
# 
# Since: Feb 2020
# Author: prakash.parmar@oracle.com
# Description: Creates an Oracle Database based on following parameters:
#              $DB_TAGLABEL:
# 

set -e

# Check whether DB_TAGLABEL is passed on
export DB_TAGLABEL=${1}
 
BOOTSTRAP_DIR=$ORACLE_DBBASE/$DB_TAGLABEL

if [ -d "$BOOTSTRAP_DIR/ORCLCDB" ]; then
    echo "$BOOTSTRAP_DIR exist ,no boostrapping required"
    echo "Will use current data"
else
cp -R /$ORACLE_DBBASE/$DB_BOOTSTRAP_DIR $BOOTSTRAP_DIR
echo "Bootstrap of database completed"
fi


