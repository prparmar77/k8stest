import time
import commands
import sys
n=1
timeelapsed=0
taglabel=sys.argv[1]
while n==1:
 cmd =  'kubectl logs %s-0 | grep "Done ! The database is ready for use ." ' %(taglabel)
 result = commands.getstatusoutput(cmd)
 if result[1] == str("Done ! The database is ready for use ."):
   print "Database is ready for use"
   print "Execute Post Database Setup Job"
   n=0
 else:
   print "Database is coming up ,hang tight"
   time.sleep(20)
   timeelapsed=timeelapsed + 20
   if timeelapsed == 1200:
    print "Looks like DB is taking little longer to start,please check after sometime by connecting from client"
    sys.exit()
   



