import time
import commands
import sys
n=1
timeelapsed=0
taglabel=sys.argv[1]
dbname = sys.argv[2]
dbpassword = sys.argv[3]
while n==1:
 cmd =  'kubectl logs %s-0 | grep "Done ! The database is ready for use ." ' %(taglabel)
 result = commands.getstatusoutput(cmd)
 if result[1] == str("Done ! The database is ready for use ."):
   print "Database is ready for use"
   print "Executing Post Creation Setup" 
   cmd = """kubectl exec -i  %s-0  -- env ORACLE_HOME=/u01/app/oracle/product/12.2.0/dbhome_1 ORACLE_SID=%s bash -c '/u01/app/oracle/product/12.2.0/dbhome_1/bin/sqlplus / as sysdba << EOF
      set head off;
      ALTER USER SYS IDENTIFIED BY '%s';  
      ALTER USER SYSTEM IDENTIFIED BY '%s';  
      exit;  
EOF'"""  %(taglabel,dbname,dbpassword,dbpassword)
   result = commands.getstatusoutput(cmd)
   print result[1]
   print "Done"

   n=0
 else:
   print "Database is coming up ,hang tight"
   time.sleep(20)
   timeelapsed=timeelapsed + 20
   if timeelapsed == 1200:
    print "Looks like DB is taking little longer to start,please check after sometime by connecting from client"
    sys.exit()
   



