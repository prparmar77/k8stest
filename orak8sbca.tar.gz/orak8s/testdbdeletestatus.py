import time
import commands
import sys
n=1
timeelapsed=0
taglabel=sys.argv[1]
while n==1:
 cmd =  'kubectl get all -l ha=%s' %(taglabel)
 result = commands.getstatusoutput(cmd)
 if result[1] == str("No resources found."):
   print "Database is deleted"
   n=0
 else:
   print "Database is going down ,hang tight"
   time.sleep(20)
   timeelapsed=timeelapsed + 20
   if timeelapsed == 300:
    exit()



