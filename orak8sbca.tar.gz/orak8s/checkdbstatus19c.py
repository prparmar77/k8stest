import time
import commands
import sys
n=1
timeelapsed=0
taglabel=sys.argv[1]
while n==1:
 cmd =  'kubectl logs %s-0 | grep "DATABASE IS READY TO USE!" ' %(taglabel)
 result = commands.getstatusoutput(cmd)
 if result[1] == str("DATABASE IS READY TO USE!"):
   print "Database is ready for use"
   # print cmd
   result = commands.getstatusoutput(cmd)
   # print result
   n=0
 else:
   print "Database is coming up ,hang tight"
   time.sleep(20)
   timeelapsed=timeelapsed + 20
   if timeelapsed == 3600:
    print "Looks like DB is taking little longer to start,please check after sometime by connecting from client"
    sys.exit()
   



