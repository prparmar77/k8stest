
SET PAGESIZE 200

ALTER SESSION SET NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS';

SELECT 'THIS REPORT WAS GENERATED AT: ==)> ' , SYSDATE " "  FROM DUAL;
SELECT 'FROM INSTANCE NAME: ==)> ' , INSTANCE_NAME " " FROM V$INSTANCE;


SELECT 'Determining Whether a Database is a CDB' from dual;
SELECT CDB FROM V$DATABASE;

SELECT 'Viewing Identifying Information About Each Container in a CDB:' from dual;


SELECT NAME, CON_ID, DBID, CON_UID, GUID FROM V$CONTAINERS ORDER BY CON_ID;

select 'Viewing Container ID, Name, and Status of Each PDB:' from dual;

 
SELECT PDB_ID, PDB_NAME, STATUS FROM DBA_PDBS ORDER BY PDB_ID;

select 'Viewing the Name and Open Mode of Each PDB' from dual;

 
SELECT NAME, OPEN_MODE, RESTRICTED, OPEN_TIME FROM V$PDBS;


select 'Showing the Users in Multiple PDBs' from dual;
 
SELECT p.PDB_ID, p.PDB_NAME, u.USERNAME   FROM DBA_PDBS p, CDB_USERS u  WHERE p.PDB_ID > 2 AND        p.PDB_ID = u.CON_ID   ORDER BY p.PDB_ID;
 
select 'Data Files for Each PDB in a CDB:' from dual;

SELECT p.PDB_ID, p.PDB_NAME, d.FILE_ID, d.TABLESPACE_NAME, d.FILE_NAME  FROM DBA_PDBS p, CDB_DATA_FILES d  WHERE p.PDB_ID = d.CON_ID  ORDER BY p.PDB_ID;
 
select 'Showing the Temp Files in a CDB' from dual;

SELECT CON_ID, FILE_ID, TABLESPACE_NAME, FILE_NAME FROM CDB_TEMP_FILES ORDER BY CON_ID;
 
select 'Showing the undo tablespaces in a CDB' from dual;

SELECT tablespace_name,CONTENTS from dba_tablespaCES where contents = 'UNDO';
 
select 'Showing the Services Associated with PDBs:' from dual;  

SELECT PDB, NETWORK_NAME, CON_ID FROM CDB_SERVICES   WHERE PDB IS NOT NULL AND CON_ID > 2 ORDER BY PDB;
 
select 'Showing history of PDBs:' from dual;    
SELECT DB_NAME, CON_ID, PDB_NAME, OPERATION, OP_TIMESTAMP, CLONED_FROM_PDB_NAME  FROM CDB_PDB_HISTORY  WHERE CON_ID > 2  ORDER BY CON_ID;
 
spool off
exit
