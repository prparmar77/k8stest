import commands
import sys
ruser=sys.argv[1]
taglabel = sys.argv[2]
cmd =  'kubectl get pod -l ruser=%s,ha=%s' %(ruser,taglabel)
result = commands.getstatusoutput(cmd)
if result[1] == str("No resources found."):
  print "No Database found under user"
  sys.exit()
   



