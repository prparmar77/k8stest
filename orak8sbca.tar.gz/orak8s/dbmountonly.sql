shutdown immediate;
startup mount;
exit
