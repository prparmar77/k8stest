set head off
select pdb_name from dba_pdbs where pdb_name not like '%$%';
